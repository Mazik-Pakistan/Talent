"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";

import RequireAccess from "@/components/RequireAccess";
import DocumentManager from "@/components/DocumentManager";
import ProfileAvatar from "@/components/ProfileAvatar";
import SidebarBrand from "@/components/SidebarBrand";
import RecruiterLoader from "@/components/recruiter/RecruiterLoader";
import {
  clearLocalSession,
  getApiErrorMessage,
  getCandidateDashboard,
  getMyEmployeeProfile,
  getNotifications,
  listMyDocuments,
  logout,
  markNotificationsRead,
} from "@/services/authService";
import { moduleAccess } from "@/services/rbac";
import { getEmployeeNavItems, isEmployeeNavActive } from "@/utils/employeeNav";
import { CANDIDATE_NAV_ITEMS, isCandidateNavActive } from "@/utils/candidateNav";
import { COPILOT_DOCUMENTS_ASSIST_EVENT, publishGuideContext, registerPageAssist } from "@/lib/ai/guideContext";
import { publishCandidateContext, clearCandidateContext } from "@/lib/ai/candidateContext";
import candidateStyles from "@/app/dashboard/candidate/candidate-dashboard.module.css";
import employeeStyles from "@/app/dashboard/employee/employee-dashboard.module.css";

const CANDIDATE_COLLAPSE_KEY = "candidate_sidebar_collapsed";
const EMPLOYEE_COLLAPSE_KEY = "employee_sidebar_collapsed";

export default function DocumentsPage() {
  return (
    <RequireAccess anyOf={["documents.self", "profile.view"]} roles={["candidate", "employee"]}>
      <DocumentsPageContent />
    </RequireAccess>
  );
}

function DocumentsPageContent() {
  const router = useRouter();
  const pathname = usePathname();

  const [user, setUser] = useState(null);
  const [profileMeta, setProfileMeta] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [loadError, setLoadError] = useState("");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);

  const isEmployee = user?.role === "employee";
  const isCandidate = user?.role === "candidate";
  const styles = isEmployee ? employeeStyles : candidateStyles;
  const profileComplete = profileMeta?.profile_status === "complete";
  const navItems = isEmployee ? getEmployeeNavItems({ profileComplete }) : CANDIDATE_NAV_ITEMS;
  const modules = moduleAccess(user?.role);

  useEffect(() => {
    setUser(JSON.parse(localStorage.getItem("user")));
  }, []);

  useEffect(() => {
    if (!user) return;
    const key = user.role === "employee" ? EMPLOYEE_COLLAPSE_KEY : CANDIDATE_COLLAPSE_KEY;
    setSidebarCollapsed(localStorage.getItem(key) === "1");
  }, [user]);

  function toggleSidebar() {
    setSidebarCollapsed((value) => {
      const next = !value;
      const key = user?.role === "employee" ? EMPLOYEE_COLLAPSE_KEY : CANDIDATE_COLLAPSE_KEY;
      localStorage.setItem(key, next ? "1" : "0");
      return next;
    });
  }

  useEffect(() => {
    if (isEmployee) {
      publishGuideContext({
        pathname: "/documents",
        section: null,
        formId: "documents",
        hint: "Upload identity and employment files, then track verification status here.",
      });
      return undefined;
    }
    if (isCandidate) {
      publishCandidateContext({
        pathname: "/documents",
        section: "documents",
        hint: "Upload clear identity documents so recruiters can verify you before offer steps.",
        fields: [],
      });
      return () => clearCandidateContext();
    }
    return undefined;
  }, [isEmployee, isCandidate]);

  useEffect(() => {
    if (!isEmployee) return registerPageAssist(null);

    return registerPageAssist({
      propose: async () => {
        const accessToken = localStorage.getItem("access_token");
        if (!accessToken) return null;
        try {
          const data = await listMyDocuments(accessToken);
          const documents = data?.documents || [];
          const problem = documents.filter((doc) =>
            ["mismatch", "rejected", "reupload_required"].includes(
              String(doc.verification_status || doc.status || "").toLowerCase()
            )
          );
          if (problem.length) {
            return {
              message: "I can take you straight to those files and keep the rest out of the way.",
              applyLabel: "Show problem files",
              doneMessage: "Problem files are now in view.",
              meta: { status: "rejected", firstId: problem[0]?.id },
            };
          }
          if (!documents.length) {
            return {
              message: "Want me to open the uploader so you can add your first document?",
              applyLabel: "Open uploader",
              doneMessage: "The uploader is ready.",
              meta: { openUploader: true, category: "identity" },
            };
          }
          return null;
        } catch {
          return null;
        }
      },
      apply: async (offer) => {
        const meta = offer.meta || {};
        window.dispatchEvent(
          new CustomEvent(COPILOT_DOCUMENTS_ASSIST_EVENT, {
            detail: {
              status: meta.status || "all",
              category: meta.category || "all",
              openUploader: !!meta.openUploader,
              replaceDocId: meta.firstId && meta.status ? meta.firstId : null,
            },
          })
        );
        await new Promise((resolve) => setTimeout(resolve, 350));
      },
    });
  }, [isEmployee]);

  const loadContext = useCallback(async () => {
    const accessToken = localStorage.getItem("access_token");
    if (!accessToken || !user) return;

    setPageLoading(true);

    try {
      const notificationData = await getNotifications(accessToken).catch(() => ({
        notifications: [],
        unread_count: 0,
      }));
      setNotifications(notificationData?.notifications || []);
      setUnreadNotifications(notificationData?.unread_count || 0);

      if (user.role === "employee") {
        const profileData = await getMyEmployeeProfile(accessToken);
        setProfileMeta(profileData.employee || null);
      } else {
        const dashboard = await getCandidateDashboard(accessToken);
        setProfileMeta(dashboard?.profile || null);
      }
      setLoadError("");
    } catch (error) {
      setLoadError(getApiErrorMessage(error, "Could not load your profile context."));
    } finally {
      setPageLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (user) loadContext();
  }, [user, loadContext]);

  async function handleLogout() {
    const accessToken = localStorage.getItem("access_token");
    await logout(accessToken);
    clearLocalSession();
    router.replace("/login");
  }

  async function handleNotification(notification) {
    const accessToken = localStorage.getItem("access_token");
    if (accessToken && !notification.read) {
      try {
        await markNotificationsRead({ ids: [notification.id], all: false }, accessToken);
        setNotifications((current) =>
          current.map((item) => (item.id === notification.id ? { ...item, read: true } : item))
        );
        setUnreadNotifications((current) => Math.max(0, current - 1));
      } catch {
        // Navigation remains available if read-state persistence is temporarily unavailable.
      }
    }
    setNotifOpen(false);
    if (notification.link) router.push(notification.link);
  }

  if (!user || pageLoading) {
    return <RecruiterLoader />;
  }

  const subtitle = isEmployee
    ? `${profileMeta?.employee_id || "—"} · ${profileMeta?.department || "—"}`
    : `${profileMeta?.job_title || "—"} · ${profileMeta?.department || "—"}`;

  return (
    <div className={styles.root} data-app-shell>
      <div className={styles.app}>
        <aside className={`${styles.sidebar} ${sidebarCollapsed ? styles.collapsed : ""}`}>
          <SidebarBrand
            collapsed={sidebarCollapsed}
            className={styles.brand}
            markClassName={styles.brandMark}
            onClick={toggleSidebar}
          />

          <div className={styles.navSectionLabel}>Workspace</div>
          <ul className={styles.nav} style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {navItems.map((item) => {
              if (isEmployee && item.module && !modules[item.module]) return null;
              const isActive = isEmployee
                ? isEmployeeNavActive(item, { pathname, activeKey: "documents" })
                : isCandidateNavActive(item, {
                    pathname,
                    search: typeof window !== "undefined" ? window.location.search : "",
                    activeKey: "documents",
                  });
              return (
                <li key={item.key}>
                  <button
                    type="button"
                    className={`${styles.navItem} ${isActive ? styles.active : ""}`}
                    onClick={() => item.href && router.push(item.href)}
                    title={item.label}
                  >
                    {item.icon}
                    <span className={styles.navLabel}>{item.label}</span>
                    {item.badge ? <span className={styles.navBadge}>{item.badge}</span> : null}
                  </button>
                </li>
              );
            })}
          </ul>

          <div className={styles.sidebarFooter}>
            <ProfileAvatar src={user?.profile_picture} name={user.full_name} size="sm" fallback="MZ" />
            <div className={styles.sidebarFooterText}>
              <div className={styles.name}>{user.full_name}</div>
              <div className={styles.role}>{profileMeta?.job_title || (isEmployee ? "Employee" : "Candidate")}</div>
            </div>
            <button type="button" className={styles.logoutBtn} title="Log out" onClick={handleLogout}>
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="M16 17l5-5-5-5" /><path d="M21 12H9" />
              </svg>
            </button>
          </div>
        </aside>

        <main className={styles.main}>
          <div className={styles.topbar}>
            <div>
              <div className={styles.topbarTitle}>Documents</div>
              <div className={styles.topbarSub}>{subtitle}</div>
            </div>
            <div className={styles.topbarActions}>
              <div className={styles.dropdownWrap}>
                <div
                  className={styles.iconBtn}
                  title="Notifications"
                  role="button"
                  tabIndex={0}
                  onClick={() => setNotifOpen((value) => !value)}
                >
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" />
                  </svg>
                  {unreadNotifications > 0 && <span className={styles.dot} />}
                </div>
                {notifOpen && (
                  <div className={styles.notifPanel}>
                    <div className={styles.notifHeading}>
                      <strong>Notifications</strong>
                      {unreadNotifications > 0 && <span>{unreadNotifications} unread</span>}
                    </div>
                    <div className={styles.notifList}>
                      {notifications.length ? (
                        notifications.slice(0, 8).map((notification) => (
                          <button
                            key={notification.id}
                            type="button"
                            className={`${styles.notifItem} ${!notification.read ? styles.unread : ""}`}
                            onClick={() => handleNotification(notification)}
                          >
                            <strong>{notification.title}</strong>
                            <span>{notification.message}</span>
                          </button>
                        ))
                      ) : (
                        <span>No notifications yet.</span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className={styles.content}>
            {loadError && <div className={styles.loadError} role="alert">{loadError}</div>}

            <div className={styles.section} style={{ marginBottom: 24 }}>
              <div className={styles.sectionHead}>
                <div className={styles.sectionHeadLeft}>
                  <div className={`${styles.bar} ${styles.orange}`} />
                  <div>
                    <div className={styles.sectionTitle}>My documents</div>
                    <div className={styles.sectionDesc}>
                      Organize files by category, download when needed, and upload updates from one place.
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.sectionBody}>
                <DocumentManager compact={false} />
              </div>
            </div>

            <div className={styles.footerNote}>
              Talent by  · {isEmployee ? "Employee" : "Candidate"} Documents
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

