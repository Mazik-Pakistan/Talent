"""Employee ↔ recruiter messaging API."""

from fastapi import APIRouter, Body

from app.core.security import RequireAny, RequireEmployee, RequireRecruiter
from app.services.message_service import message_service

router = APIRouter(prefix="/api/messages", tags=["Messages"])


@router.get("")
async def list_threads(current_user: RequireAny):
    if current_user.role in ("recruiter", "super_admin"):
        return await message_service.list_threads_for_recruiter(current_user)
    return await message_service.list_threads_for_employee(current_user)


@router.get("/{thread_id}")
async def get_thread(thread_id: str, current_user: RequireAny):
    return await message_service.get_thread(current_user, thread_id)


@router.post("", status_code=201)
async def employee_send_message(current_user: RequireEmployee, payload: dict = Body(...)):
    """Employee starts or replies to an HR conversation."""
    body = payload if isinstance(payload, dict) else {}
    return await message_service.employee_send(
        current_user,
        body=body.get("body") or "",
        subject=body.get("subject"),
        thread_id=body.get("thread_id"),
    )


@router.post("/start", status_code=201)
async def recruiter_start_message(current_user: RequireRecruiter, payload: dict = Body(...)):
    """Recruiter starts (or continues) a conversation with an employee."""
    body = payload if isinstance(payload, dict) else {}
    return await message_service.recruiter_start(
        current_user,
        employee_id=body.get("employee_id") or "",
        body=body.get("body") or "",
        subject=body.get("subject"),
    )


@router.post("/{thread_id}/reply", status_code=201)
async def recruiter_reply(thread_id: str, current_user: RequireRecruiter, payload: dict = Body(...)):
    body = payload if isinstance(payload, dict) else {}
    return await message_service.recruiter_reply(current_user, thread_id, body=body.get("body") or "")


@router.post("/{thread_id}/close")
async def close_thread(thread_id: str, current_user: RequireAny):
    return await message_service.close_thread(current_user, thread_id)
